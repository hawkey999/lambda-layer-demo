var_from_test2 = 'this is var in test2'
